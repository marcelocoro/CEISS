/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cifradocesar;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author redes
 */
public class CifradoCesar {
    static List<Character> onlyWith;
    static List<Character> onlyWith2;
    public static void main(String[] args) {
        setValidChars();
        decipherCeasar();
    }
    public static void setValidChars(){
        onlyWith = new ArrayList();
        onlyWith2 = new ArrayList();
        char a = 'a';
        for(int i = 0; i <= 25; i++)
        {
            onlyWith.add((char)(a + i));
            onlyWith2.add((char)(a+i));
            System.out.print(i);
            System.out.println(onlyWith.get(i));
        }
        a = 'a';
        for(int i = 0; i <= 25; i++)
        {
            onlyWith.add((char)(a + i));
        }
        //for(char c : onlyWith)
            //System.out.println(c);
    }
    public static void decipherCeasar(){
        String s = "bmeufambmeufaegmhqegmhqoufa";
        for (int i = 0; i <= 24 ; i++){
            String sModified = "";
            for(int j = 0; j< s.length(); j++){
                char c = s.charAt(j);
                int pos = onlyWith2.indexOf(c);
                int npos = pos + i;
                sModified = sModified + onlyWith.get(npos);
            }
            System.out.println(sModified);
        }
        
    }
}
